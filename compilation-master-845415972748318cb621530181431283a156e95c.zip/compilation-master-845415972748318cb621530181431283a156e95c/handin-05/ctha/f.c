// function declaration


int main() {
char greeting[] = "Hello";
return 0;
}
