clang -o result.bin $1.ll runtime.c
./result.bin
echo $?
