

start dette script med ./run.sh filename hvor filename er navnet på llvm code uden .ll

scripted compiler koden til result.bin
scripted køre en echo $?

eks.

./run.sh if2
