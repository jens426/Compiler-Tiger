// AU Compilation course
// Please do not distribute
//



int tigermain(void *, int);

int main(int argc, char *argv[])
{

    int result;

    result = tigermain(0, 1000);
    return result;
}